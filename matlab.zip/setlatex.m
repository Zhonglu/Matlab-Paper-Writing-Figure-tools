function setlatex
%startup
    set(groot, 'defaultAxesTickLabelInterpreter','latex'); 
    set(groot, 'defaultLegendInterpreter','latex');
    set(0,'defaultlinelinewidth',1.2)
    set(0,'defaultaxeslinewidth',1.2)
    set(0,'defaultpatchlinewidth',1.2)
    set(0,'DefaultAxesFontSize',20)
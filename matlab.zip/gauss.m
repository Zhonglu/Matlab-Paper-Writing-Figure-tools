function y=gauss(x)
    y=exp(-x.^2);

end
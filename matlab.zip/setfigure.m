function setfigure           
set(gca,'Linewidth',1.2);set(gca, 'FontSize', 20);
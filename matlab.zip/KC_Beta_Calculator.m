clear all
close all

prompt = 'Input A1: ';
A1 = input(prompt);
KC=2*pi*A1
Re=100;
beta=Re/KC

